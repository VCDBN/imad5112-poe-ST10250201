package com.mishen.st10250201_calculatorapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class StatisticsActivity : AppCompatActivity() {
    private val numbersArray = IntArray(10) //Array to store integers
    private var currentIndex = 0// Keep track of the current position in the array
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics)
        val numberEditText = findViewById<EditText>(R.id.statsNum)
        val addButton = findViewById<Button>(R.id.StatsAddBtn)
        val clearButton = findViewById<Button>(R.id.ClearBtn)
        val minMaxButton = findViewById<Button>(R.id.MinMaxBtn)
        val averageButton = findViewById<Button>(R.id.AverageBtn)
        val numberDisplay=findViewById<TextView>(R.id.textView2)
        val answerView = findViewById<TextView>(R.id.AnswerView)
        addButton.setOnClickListener {
            if (currentIndex < 10) {    // Check if there is space in the array to add more numbers
                addNumber(numberEditText.text.toString())
                currentIndex++
                updateNumbersView()
            } else {
                Toast.makeText(this, "You can only enter up to 10 integers", Toast.LENGTH_SHORT).show()
            }
        }

        clearButton.setOnClickListener {
            clearNumbers()
            currentIndex = 0
            updateNumbersView()
            answerView.text = "Answer:"
        }

        minMaxButton.setOnClickListener {
            if (currentIndex > 0) {      // Calculate and display the min and max values
                val (min, max) = findMinMax()
                answerView.text = "Min: $min, Max: $max"
            } else {
                answerView.text = "No numbers entered yet"
            }
        }
        // Calculate and display the average
        averageButton.setOnClickListener {
            if (currentIndex > 0) {
                val average = calculateAverage()
                answerView.text = "Average: $average"
            } else {
                answerView.text = "No numbers entered yet"
            }
        }
    }

    private fun addNumber(number: String) {
        try {
            val num = number.toInt()
            numbersArray[currentIndex] = num
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearNumbers() {
        numbersArray.fill(0)
    }

    private fun updateNumbersView() {
        val textView = findViewById<TextView>(R.id.textView2)
        textView.text = "Numbers stored in memory: ${numbersArray.filter { it != 0 }}"
    }

    private fun findMinMax(): Pair<Int, Int> {
        var min = Int.MAX_VALUE
        var max = Int.MIN_VALUE

        for (i in 0 until currentIndex) {
            val num = numbersArray[i]
            if (num < min) {
                min = num
            }
            if (num > max) {
                max = num
            }
        }

        return Pair(min, max)
    }

    private fun calculateAverage(): Double {
        var sum = 0
        for (i in 0 until currentIndex) {
            sum += numbersArray[i]
        }
        return sum.toDouble() / currentIndex
    }
}

//code attribution
//The following method was taken from Java Guides:
//link:https://www.javaguides.net/2023/09/kotlin-calculate-average-of-numbers-in-an-array.html#:~:text=Average%20Derivation%3A%20Post%20loop%20traversal,this%20value%20to%20the%20user.
//   private fun calculateAverage(): Double {
//        var sum = 0
//        for (i in 0 until currentIndex) {
//            sum += numbersArray[i]
//        }
//        return sum.toDouble() / currentIndex
//    }
//end