package com.mishen.st10250201_calculatorapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val num1 = findViewById<EditText>(R.id.Number1)
        val num2 = findViewById<EditText>(R.id.Number2)
        val additionBtn = findViewById<Button>(R.id.AddBtn)
        val subtBtn = findViewById<Button>(R.id.SubtractBtn)
        val multBtn = findViewById<Button>(R.id.MultiplyBtn)
        val divBtn = findViewById<Button>(R.id.DivideBtn)
        val srBtn = findViewById<Button>(R.id.SquareRootBtn)
        val pBtn = findViewById<Button>(R.id.PowerBtn)
        val resultTextView = findViewById<TextView>(R.id.resultTextView)
        val statisticsBtn = findViewById<Button>(R.id.StatisticsBtn)
        statisticsBtn.setOnClickListener {
            // Create an Intent to start the StatisticsActivity
            val intent = Intent(this, StatisticsActivity::class.java)
            startActivity(intent)
        }
        additionBtn.setOnClickListener {
            val addnum1 = num1.text.toString().toInt()
            val addnum2 = num2.text.toString().toInt()
            val result = addnum1 + addnum2
            resultTextView.text = "$addnum1 + $addnum2 = $result"

        }
        multBtn.setOnClickListener {
            val multnum1 = num1.text.toString().toInt()
            val multnum2 = num2.text.toString().toInt()
            val resultmultiply = multnum1 * multnum2
            resultTextView.text = "$multnum1 x $multnum2 = $resultmultiply"
        }
        subtBtn.setOnClickListener {
            val subnum1 = num1.text.toString().toInt()
            val subnum2 = num2.text.toString().toInt()
            val resultsubtract = subnum1 - subnum2
            resultTextView.text = "$subnum1 - $subnum2 = $resultsubtract"
        }
        divBtn.setOnClickListener {
            val divnum1 = num1.text.toString().toInt()
            val divnum2 = num2.text.toString().toInt()
            if (divnum2 != 0) {
                val result = divnum1 / divnum2
                resultTextView.text = "$divnum1 / $divnum2 = $result"
            } else {
                resultTextView.text = "Division by zero is not allowed"
            }
        }
        srBtn.setOnClickListener {
            val num1Text = num1.text.toString().toDouble()
            val num2Text = num2.text.toString()

            if (num2Text.isEmpty()) {
                if (num1Text >= 0) { // Non-negative number
                    val resultSqrt = Math.sqrt(num1Text)
                    resultTextView.text = "sqrt($num1Text) = $resultSqrt"
                } else { // Negative number
                    val absNum1 = Math.abs(num1Text) // Calculate absolute value
                    val resultSqrt = Math.sqrt(absNum1)
                    resultTextView.text = "sqrt($num1Text) = ${resultSqrt}i"
                }
            } else {
                resultTextView.text = "Please leave 'Number 2' empty for square root calculation."
            }
        }
        pBtn.setOnClickListener {
            val num1Text = num1.text.toString().toDouble()
            val num2Text = num2.text.toString().toInt()

            if (num2Text >= 0) {
                var result = 1.0
                for (i in 1..num2Text) {
                    result *= num1Text
                }
                resultTextView.text = "$num1Text^$num2Text = $result"
            } else {
                resultTextView.text = "Exponent must be a non-negative integer"
            }

        }
    }
}
//code attribution
//The following method was taken from Code Academy
//link:https://www.codecademy.com/resources/docs/kotlin/math-methods/pow
// val num1Text = num1.text.toString().toDouble()
//            val num2Text = num2.text.toString().toInt()
//
//            if (num2Text >= 0) {
//                var result = 1.0
//                for (i in 1..num2Text) {
//                    result *= num1Text
//                }
//                resultTextView.text = "$num1Text^$num2Text = $result"
//            } else {
//                resultTextView.text = "Exponent must be a non-negative integer"
//            }
//
//        }
//end
